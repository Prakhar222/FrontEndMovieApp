import { combineReducers } from "redux";
import movieReducer from "./movieReducer.js";
import screeningReducer from "./screeningReducer.js";
import theatreReducer from "./theatreReducer.js";
import seatReducer from "./seatReducer.js";
export default combineReducers({
   movies:movieReducer,
   theatres:theatreReducer,
   screenings:screeningReducer,
   seats:seatReducer
});