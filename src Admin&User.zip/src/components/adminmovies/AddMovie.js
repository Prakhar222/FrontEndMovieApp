import React, { Component } from 'react';
import PropTypes from "prop-types"
import {connect} from "react-redux"
import {createMovies} from "../../actions/AdminMovieActions"
class AddMovie extends Component {
    constructor(props){
        super(props);
        this.state={
            title:"",
            poster:"",
            genre:"",
            duration:""
        };
        this.onChange=this.onChange.bind(this);
        this.onSubmit=this.onSubmit.bind(this);
    }
    onChange(event){
        this.setState({[event.target.name]:event.target.value});
    }
    onSubmit(event){
        event.preventDefault();
        const newMovie={
            title:this.state.title,
            poster:this.state.poster,
            genre:this.state.genre,
            duration:this.state.duration,
       
        
        }
        console.log(newMovie);
        this.props.createMovies(newMovie,this.props.history);

    }
   
    render() {

        return (
            <div className="movie">
            <div className="container">
                <div className="row">
                    <div className="col-md-8 m-auto">
                        <h5 className="display-4 text-center">Create / Edit Movie </h5>
                        <hr />
                        <form onSubmit={this.onSubmit}>
                            <div className="form-group">
                                <input type="text" className="form-control form-control-lg " placeholder="Movie Title" name="title" value={this.state.title} onChange={this.onChange} />
                            </div>
                           
                            <div className="form-group">
                                <input type="text" className="form-control form-control-lg" placeholder="Movie Poster"
                                name="poster" value={this.state.poster} onChange={this.onChange} />
                            </div>
                            
                            <div className="form-group">
                                <textarea className="form-control form-control-lg" placeholder="Movie Genre" name="genre" value={this.state.genre} onChange={this.onChange}></textarea>
                            </div>
                           
                            <h6>Movie Duration</h6>
                            <div className="form-group">
                                <input type="text" className="form-control form-control-lg" name="duration" value={this.state.duration} onChange={this.onChange} />
                            </div>
                           
                            <input type="submit" className="btn btn-primary btn-block mt-4" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
        );
    }
}

AddMovie.propTypes={
    createMovies:PropTypes.func.isRequired,
   
};
const mapStateToProps=state=>({
    adminErrors:state.adminErrors
})

export default connect(mapStateToProps,{createMovies}) (AddMovie);
//export default AddProject;