import { GET_ADMIN_ERRORS } from "../actions/Types";
const initialState={};
export default function(state=initialState,action){
    switch(action.type){
        case GET_ADMIN_ERRORS:
            return action.payload;
            default:
                return state;
    }
}