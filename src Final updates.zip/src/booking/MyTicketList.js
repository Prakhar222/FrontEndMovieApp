import React, { Component } from 'react';
import { getSeatsBookingByUserId } from '../actions/SeatBookingAction.js';
import { connect } from 'react-redux';
import MyTicketItem from './MyTicketItem.js';

class MyTicketList extends Component {
    componentDidMount(){
      const userId=JSON.parse(localStorage.getItem('user'));
       this.props.getSeatsBookingByUserId(userId)
    }

    render() {
        const {seatBookings}=this.props.seatBookings
        const userId=JSON.parse(localStorage.getItem('user'));;
        if(userId==null|| userId==0)
        {
            this.props.history.push("/sign-up");
        }
        
        return (
            <div>
                  {seatBookings.map(seatBooking=>(
                <MyTicketItem key={seatBooking.id} seatBooking={seatBooking} />
             ) ) }
            </div>
        );
    }
}

// export default MyTicketList;

const mapStateToProps=state=>({
    seatBookings:state.seatBookings
   })
  export default connect(mapStateToProps,{getSeatsBookingByUserId}) (MyTicketList);