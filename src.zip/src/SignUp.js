import React, { useState } from 'react';
import { useHistory } from 'react-router';
import { auth } from './firebase';
import './App.css';

export const Signup = () => {
  // const [profile, setprofile] = useState('');
  // const [url, seturl] = useState('');
  // const [name, setname] = useState('');
  const [email, setemail] = useState('');
  const [password, setpassword] = useState('');
  // const [mobile, setmobile] = useState('');
  const [admin, setadmin] = useState(false);
  const history = useHistory();
  const signUp = () => {
    var container = document.getElementById('container');
    container.classList.add("right-panel-active");
  };
  const signIn = () => {
    var container = document.getElementById('container');
    container.classList.remove("right-panel-active");
  };
  const handleSubmit = (e) => {
    e.preventDefault();

           auth.createUserWithEmailAndPassword(email,password).then(

            user => console.log(user)

            ).catch(err => console.log(err))

           alert("sigup completed");

  }

  const handleLogin = (e) => {
    e.preventDefault();

    auth.signInWithEmailAndPassword(email,password).then(

       user => console.log(user)

       ).catch(err => console.log(err))

        if (email === email && password === password) {
          history.push({ pathname: "/adminpage", state: {email: email, password: password} })//profile: profile, name: name, , mobile: mobile
        } else {
          alert("invalid email or password");
        }

      history.push({ pathname: "/homepage", state: {  email: email, password: password } })//profile: profile, name: name,, mobile: mobile

            history.push({ pathname: "/homepage", state: {  email: email, password: password } })//profile: profile, name: name,, mobile: mobile
  }
  return (
    <div className="position-relative">
      <h2>Movie Ticket Booking App</h2>
      <div class="container" id="container">
        <div class="form-container sign-up-container">
          <form>
            <h1>Create Account</h1>
            <div class="social-container">
              <a href="#" class="social"><i class="fa fa-facebook"></i></a>
              <a href="#" class="social"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="social"><i class="fa fa-linkedin"></i></a>
            </div>
            <span>or use your email for registration</span>
            {/* <input type="file" placeholder="Pick Image" onChange={(e) => setprofile(e.target.files[0])} />
            <input type="text" placeholder="Name" value={name} onChange={(e) => setname(e.target.value)} /> */}
            <input type="email" placeholder="Email" value={email} onChange={(e) => setemail(e.target.value)} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setpassword(e.target.value)} />
            {/* <input type="text" placeholder="Mobile" value={mobile} onChange={(e) => setmobile(e.target.value)} /> */}
            <button onClick={handleSubmit}>Sign Up</button>
          </form>
        </div>
        <div class="form-container sign-in-container">
          <form>
            <h1>Sign in</h1>
            <div class="social-container">
              <a href="#" class="social"><i class="fa fa-facebook"></i></a>
              <a href="#" class="social"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="social"><i class="fa fa-linkedin"></i></a>
            </div>
            <span>or use your account</span>
            <input type="email" value={email} onChange={(e) => setemail(e.target.value)} placeholder="Email" />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setpassword(e.target.value)} />
            {/* <input type="checkbox" style={{ marginLeft: "-66%", width: "-webkit-fill-available" }} value={admin} onChange={(e) => setadmin(true)} /><a href="#" style={{ marginLeft: "-8%", marginTop: "-8%" }}>Pick If You Are Admin</a> */}
            <button onClick={handleLogin}>Sign In</button>
          </form>
        </div>
        <div class="overlay-container">
          <div class="overlay">
            <div class="overlay-panel overlay-left">
              <h1>Welcome Back!</h1>
              <p>To keep connected with us please login with your personal info</p>
              <button class="ghost" id="signIn" onClick={signIn}>Sign In</button>
            </div>
            <div class="overlay-panel overlay-right">
              <h1>Hello, Friend!</h1>
              <p>Enter your personal details and start journey with us</p>
              <button class="ghost" id="signUp" onClick={signUp}>Sign Up</button>
            </div>
          </div>
        </div>
      </div>


    </div>
  )
}
export default Signup;