import axios from "axios";
import { useRef } from "react";
export const checkUserDetails=(user,history)=>async dispatch=>{

    try {
        const res=await axios.get("http://localhost:8088/user/check",user);
        if(res==true)
        history.push("/dashboard");
    } catch (error) {
       
    }
}
