import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Signup from './SignUp';
import { Provider } from 'react-redux';
import store from "./Store.js";
import Dashboard from './components/Dashboard.js';
import TheatreList from "./components/theatres/TheatreList.js";
import ShowScreening from './components/screening/ShowScreening.js';
import { auth } from "./firebase.js";
import { useEffect, useState } from 'react';
function App() {

    return (
        <div>

            <Provider store={store}>
                <Router>

                    <div className="wrapper ">
                        <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
                        <div className="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                            <div className="logo"><a href="/dashboard" className="simple-text logo-normal">
                                Movie Booking app
                            </a></div>
                            <div className="sidebar-wrapper">
                                <ul className="nav">
                                    <li className="nav-item active  ">
                                        <Link to={"/dashboard"} className="nav-link">
                                            <i className="material-icons">Home</i>
                                            <br />
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link to={{ pathname: "/admin" }} className="nav-link">
                                            <i className="material-icons">Screening</i>
                                            <br />
                                        </Link>
                                    </li>
                                    {/*<li className="nav-item ">
                                    <Link to={"/dashboard"} className="nav-link">
                                        <i className="material-icons">Dashboard</i>
                                        <br />
                                    </Link>
    </li>*/}
                                    <li className="nav-item ">
                                        <Link to={{ pathname: "/userprofile" }} className="nav-link">
                                            <i className="material-icons">User</i>
                                            <br />
                                        </Link>
                                    </li>
                                    <li className="nav-item ">
                                        <Link to={"/sign-up"} className="nav-link" >
                                            <i className="material-icons">Signup</i>
                                            <br />
                                        </Link>
                                    </li>
                                    <li className="nav-item ">
                                        <Link to={"/"} className="nav-link">
                                            <i className="material-icons">Logout</i>
                                            <br />
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="main-panel">
                            <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                                <div class="container-fluid">
                                    <div class="navbar-wrapper">
                                    </div>
                                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="navbar-toggler-icon icon-bar"></span>
                                        <span class="navbar-toggler-icon icon-bar"></span>
                                        <span class="navbar-toggler-icon icon-bar"></span>
                                    </button>
                                </div>
                            </nav>
                        </div>

                        <div className="outer">
                            <div className="inner">
                                <Switch>
                                    <Route path="/dashboard" component={Dashboard} />
                                    <Route path="/showscreening/:id" component={ShowScreening} />
                                    <Route path="/theatres/:id" component={TheatreList} />
                                    <Route path="/sign-up" component={Signup} />
                                </Switch>
                            </div>
                        </div>
                    </div></Router>
            </Provider>
        </div>
    );
}

export default App;