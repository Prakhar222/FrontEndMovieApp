import React, { Component } from 'react';
import axios from 'axios';
import {getScreeningsByMovieId} from "../../actions/ScreeningAction.js";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import Loader from "react-loader-spinner";
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import TheatreScreeningView from './TheatreScreeningView.js';

class TheatreItem extends Component {
    state = {
        screenings:[]

      };
    
    componentDidMount(){
      
      this.props.getScreeningsByMovieId(this.props.movieId);

            }
    render() {


         const{screenings}=this.props.screenings;
       
        
        const{theatre}=this.props;
        const screenings2=screenings.filter(s=>s.auditorium.theatre.id===theatre.id);
        console.log(screenings.length);
        // console.log(screenings2.length);
        return (
            <div className="card">
                <h4>{theatre.name}</h4>
                <h5>{theatre.city}</h5>
                {screenings2.map(screening=>(
                <TheatreScreeningView key={screening.id} screening={screening} />
                
             ) ) }
             <Link to="#">
                                    <li className="list-group-item board">
                                    <button className="btn btn-dark">Select Theatre</button>
                                    </li>
                                    </Link>
            </div>
        );
    }
}
const mapStateToProps=state=>({
    screenings:state.screenings
   })
  export default connect(mapStateToProps,{getScreeningsByMovieId}) (TheatreItem);