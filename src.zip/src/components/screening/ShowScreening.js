import React, { Component } from 'react';
import { getScreeningById } from '../../actions/ScreeningAction.js';
import { connect } from 'react-redux';
import { getSeatsByScreeningId } from '../../actions/SeatActions.js';
import SeatList from '../seats/SeatList.js';

class ShowScreening extends Component {
 
    componentDidMount(){
        this.props.getScreeningById(this.props.match.params.id);
        this.props.getSeatsByScreeningId(this.props.match.params.id);
       
    }
    
    render() {
       
        const{seats}=this.props.seats;
        const{screening}=this.props.screenings;
      
        return (
            <div>
                <h1>{screening.startTime}</h1>
                {seats.map(seat=>(
                   <SeatList key={seat.id} seat={seat} />
             ) ) }
                
            </div>
        );
    }
}


const mapStateToProps=state=>({
    screenings:state.screenings,
    seats:state.seats
   })
  export default connect(mapStateToProps,{getScreeningById,getSeatsByScreeningId}) (ShowScreening);